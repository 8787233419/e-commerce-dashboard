const Home = () => {
    return (
      <div className="home" >
        <h2>Home Section</h2>
        <div className="categories" style={{ marginTop: '1000px'}}>
          <h2>Categories</h2>
          <p>Click on the categories link in the navbar to see the categories</p>
        </div>
      </div>
    );
  }
   
  export default Home;